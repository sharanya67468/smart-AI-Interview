package com.smarthire.config;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
public class SecurityConfig {
 @Bean SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
   http.csrf(csrf->csrf.disable()).cors(cors->{}).authorizeHttpRequests(auth->auth.anyRequest().permitAll());
   return http.build();
 }
}
